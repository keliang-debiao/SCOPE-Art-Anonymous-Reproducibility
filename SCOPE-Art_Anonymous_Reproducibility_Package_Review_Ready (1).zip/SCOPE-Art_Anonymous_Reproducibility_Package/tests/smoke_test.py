import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/'src'))
import torch, numpy as np
from scope_art.model import ScopeArtCore
from scope_art.losses import total_loss
from scope_art.metrics import retrieval_metrics

torch.manual_seed(1)
B,R,D,L=8,16,64,3
m=ScopeArtCore(d=D,k=4,r=16,top_k=2)
rgb=torch.randn(B,R,D); edge=torch.randn(B,R,D); lenses=torch.randn(B,L,D); mask=torch.tensor([[1,1,1],[1,0,1],[1,1,0],[1,1,1],[1,0,1],[1,1,1],[1,1,0],[1,1,1]],dtype=torch.bool)
zi,pii=m.image_forward(rgb,edge); zt,w,pit=m.text_forward(lenses,mask)
loss,parts=total_loss(zi,zt,lenses=lenses,lens_mask=mask,lambda_s=0,lambda_l=.25)
sim=(zi@zt.T).detach().numpy(); metrics=retrieval_metrics(sim)
assert zi.shape==(B,D) and zt.shape==(B,D)
assert torch.allclose(zi.norm(dim=1),torch.ones(B),atol=1e-5)
assert np.isfinite(loss.item())
print('SMOKE TEST PASSED')
print('loss_parts=',parts)
print('metrics_schema=',metrics)
