# Data acquisition

## The Met development collection

Use the public The Metropolitan Museum of Art Open Access/Kaggle release. Preserve the downloaded metadata version and record checksums. This repository does not redistribute museum images.

Required fields after harmonization:
- artwork identifier
- image path
- title
- creator/maker
- date/period
- material/technique/support

## Prado external collection

Use the public `Prado Museum Pictures` Kaggle release. Preserve the original package and record checksums. The Kaggle package-level license and underlying museum image reuse conditions should be treated separately.

## Final manifests

The code creates artwork-level manifests and does not assume that public source-level record counts equal the final analytic cohort. Filtering, file integrity, primary-view selection, duplicate screening, and contextual-field eligibility determine the actual final N.
