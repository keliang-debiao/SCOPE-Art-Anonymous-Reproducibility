import numpy as np
from scipy.optimize import minimize_scalar

def softmax(x):
    x=x-x.max(axis=1,keepdims=True); e=np.exp(x); return e/e.sum(axis=1,keepdims=True)

def fit_temperature(sim):
    y=np.arange(sim.shape[0])
    def nll(logT):
        T=np.exp(logT); p=softmax(sim/T); return -np.mean(np.log(p[np.arange(len(y)),y]+1e-12))
    res=minimize_scalar(nll,bounds=(-4,4),method='bounded'); return float(np.exp(res.x))

def top1_conf_correct(sim,T):
    p=softmax(sim/T); pred=p.argmax(1); return p.max(1), (pred==np.arange(len(pred))).astype(float)
