import numpy as np

def ranks(sim):
    # assumes diagonal positives
    order=np.argsort(-sim,axis=1); true=np.arange(sim.shape[0])[:,None]
    return np.argmax(order==true,axis=1)+1

def retrieval_metrics(sim,ks=(1,5,10)):
    ri=ranks(sim); rt=ranks(sim.T); out={}
    for k in ks:
        out[f'i2t_r@{k}']=float(np.mean(ri<=k)); out[f't2i_r@{k}']=float(np.mean(rt<=k)); out[f'bi_r@{k}']=0.5*(out[f'i2t_r@{k}']+out[f't2i_r@{k}'])
    out['i2t_mrr']=float(np.mean(1/ri)); out['t2i_mrr']=float(np.mean(1/rt)); out['mrr']=0.5*(out['i2t_mrr']+out['t2i_mrr']); return out

def ece(conf,correct,bins=15):
    edges=np.linspace(0,1,bins+1); val=0.0
    for a,b in zip(edges[:-1],edges[1:]):
        m=(conf>=a)&((conf<b) if b<1 else (conf<=b))
        if m.any(): val += m.mean()*abs(correct[m].mean()-conf[m].mean())
    return float(val)

def brier(conf,correct): return float(np.mean((conf-correct)**2))
