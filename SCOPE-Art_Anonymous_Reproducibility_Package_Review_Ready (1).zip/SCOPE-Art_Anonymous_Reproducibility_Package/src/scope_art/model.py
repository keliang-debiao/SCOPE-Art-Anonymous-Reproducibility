import torch
import torch.nn as nn
import torch.nn.functional as F

class StructuralResidualTokenMixer(nn.Module):
    def __init__(self,d):
        super().__init__(); self.edge_proj=nn.Linear(d,d); self.gate=nn.Linear(3*d,d)
    def forward(self,v,e):
        g=torch.sigmoid(self.gate(torch.cat([v,e,(v-e).abs()],dim=-1)))
        return v + g*self.edge_proj(e)

class ContextLensFactorization(nn.Module):
    def __init__(self,d):
        super().__init__(); self.score=nn.Linear(d,1,bias=False)
    def forward(self,lens_emb,mask):
        # lens_emb: [B,L,D], mask:[B,L]
        score=self.score(lens_emb).squeeze(-1).masked_fill(~mask.bool(),-1e4)
        w=torch.softmax(score,dim=-1)
        return (w.unsqueeze(-1)*lens_emb).sum(1), w

class SharedBasisCrossModalExperts(nn.Module):
    def __init__(self,d=768,k=6,r=64,top_k=2):
        super().__init__(); self.d=d; self.k=k; self.r=r; self.top_k=top_k
        self.U=nn.Parameter(torch.randn(k,d,r)*0.02)
        self.a_img=nn.ModuleList([nn.Linear(r,r,bias=False) for _ in range(k)])
        self.c_img=nn.ModuleList([nn.Linear(r,r,bias=False) for _ in range(k)])
        self.a_txt=nn.ModuleList([nn.Linear(r,r,bias=False) for _ in range(k)])
        self.c_txt=nn.ModuleList([nn.Linear(r,r,bias=False) for _ in range(k)])
    def bases(self):
        return torch.stack([torch.linalg.qr(self.U[i],mode='reduced').Q for i in range(self.k)])
    def forward(self,h,modality='image',routing_temp=1.0):
        B=self.bases() # K,D,R
        proj=torch.einsum('kdr,bd->bkr',B,h)
        q=(proj.pow(2).sum(-1)/(h.pow(2).sum(-1,keepdim=True)+1e-8))
        pi=torch.softmax(q/routing_temp,dim=-1)
        vals,idx=pi.topk(self.top_k,dim=-1); vals=vals/vals.sum(-1,keepdim=True)
        outs=[]
        for b in range(h.size(0)):
            ob=0
            for w,kidx in zip(vals[b],idx[b]):
                k=int(kidx); z=proj[b,k]
                if modality=='image': y=self.a_img[k](F.gelu(self.c_img[k](z)))
                else: y=self.a_txt[k](F.gelu(self.c_txt[k](z)))
                ob=ob+w*(h[b]+B[k]@y)
            outs.append(ob)
        return F.normalize(torch.stack(outs),dim=-1), pi

class ScopeArtCore(nn.Module):
    """Backbone-agnostic SCOPE-Art core used after pretrained token/embedding extraction."""
    def __init__(self,d=768,k=6,r=64,top_k=2):
        super().__init__(); self.srtm=StructuralResidualTokenMixer(d); self.clf=ContextLensFactorization(d); self.scbe=SharedBasisCrossModalExperts(d,k,r,top_k)
    def image_forward(self,rgb_tokens,edge_tokens):
        h=self.srtm(rgb_tokens,edge_tokens).mean(1)
        return self.scbe(h,'image')
    def text_forward(self,lens_embeddings,lens_mask):
        h,w=self.clf(lens_embeddings,lens_mask)
        z,pi=self.scbe(h,'text')
        return z,w,pi
