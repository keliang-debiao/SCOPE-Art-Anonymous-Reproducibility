from pathlib import Path
import pandas as pd
from PIL import Image
import imagehash
from sklearn.model_selection import GroupKFold
from .utils import sha256_file

REQUIRED=['sample_id','image_path','title','creator','date','material']

def load_manifest(path):
    df=pd.read_csv(path)
    missing=[c for c in REQUIRED if c not in df.columns]
    if missing: raise ValueError(f"Missing columns: {missing}")
    return df


def add_hashes(df, phash_size=8):
    out=df.copy(); sha=[]; ph=[]; ok=[]
    for p in out.image_path:
        try:
            sha.append(sha256_file(p))
            with Image.open(p) as im:
                ph.append(str(imagehash.phash(im.convert('RGB'), hash_size=phash_size)))
            ok.append(True)
        except Exception:
            sha.append(None); ph.append(None); ok.append(False)
    out['sha256']=sha; out['phash']=ph; out['decodable']=ok
    return out


def hamming_hex(a,b):
    return bin(int(a,16)^int(b,16)).count('1')


def cross_collection_audit(met, prado, threshold=6):
    exact=[]; near=[]
    sha_to_met={s:i for i,s in zip(met.sample_id,met.sha256) if isinstance(s,str)}
    for row in prado.itertuples():
        if isinstance(row.sha256,str) and row.sha256 in sha_to_met:
            exact.append((sha_to_met[row.sha256], row.sample_id))
    # brute force is for small/test manifests; full runs should use LSH/banding index
    # to avoid O(N*M). This branch remains exact and reproducible.
    met_ph=[(sid,p) for sid,p in zip(met.sample_id,met.phash) if isinstance(p,str)]
    if len(met_ph)*len(prado) <= 5_000_000:
        for r in prado.itertuples():
            if not isinstance(r.phash,str): continue
            for sid,p in met_ph:
                d=hamming_hex(p,r.phash)
                if d<=threshold: near.append((sid,r.sample_id,d))
    return exact, near


def make_group_folds(df, n_splits=5):
    groups=df['duplicate_group'] if 'duplicate_group' in df else df['sample_id']
    splitter=GroupKFold(n_splits=n_splits)
    fold=pd.Series(index=df.index,dtype='int64')
    for k,(_,val) in enumerate(splitter.split(df,groups=groups)):
        fold.iloc[val]=k
    out=df.copy(); out['fold']=fold.astype(int)
    return out
