import numpy as np
from scipy.stats import wilcoxon

def bootstrap_delta(a,b,n=10000,seed=2026):
    rng=np.random.default_rng(seed); a=np.asarray(a); b=np.asarray(b); d=a-b; vals=[]
    for _ in range(n):
        idx=rng.integers(0,len(d),len(d)); vals.append(d[idx].mean())
    lo,hi=np.quantile(vals,[.025,.975]); return float(d.mean()),float(lo),float(hi)

def cliffs_delta(a,b):
    a=np.asarray(a); b=np.asarray(b); gt=sum(x>y for x,y in zip(a,b)); lt=sum(x<y for x,y in zip(a,b)); return (gt-lt)/len(a)
