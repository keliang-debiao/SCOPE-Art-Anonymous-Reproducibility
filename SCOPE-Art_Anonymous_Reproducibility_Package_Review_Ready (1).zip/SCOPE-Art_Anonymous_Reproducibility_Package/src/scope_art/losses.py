import torch
import torch.nn.functional as F

def symmetric_infonce(img,txt,temp=0.07):
    logits=img@txt.T/temp; target=torch.arange(img.size(0),device=img.device)
    return 0.5*(F.cross_entropy(logits,target)+F.cross_entropy(logits.T,target))

def total_loss(img,txt,edge=None,lenses=None,lens_mask=None,lambda_s=0.25,lambda_l=0.25,temp=0.07):
    ret=symmetric_infonce(img,txt,temp); total=ret; out={'retrieval':float(ret.detach())}
    if edge is not None:
        ls=symmetric_infonce(edge,txt,temp); total=total+lambda_s*ls; out['structural']=float(ls.detach())
    if lenses is not None and lens_mask is not None:
        vals=[]
        for l in range(lenses.size(1)):
            keep=lens_mask[:,l].bool()
            if keep.sum()>1: vals.append(symmetric_infonce(img[keep],F.normalize(lenses[keep,l],dim=-1),temp))
        if vals:
            ll=torch.stack(vals).mean(); total=total+lambda_l*ll; out['lens']=float(ll.detach())
    out['total']=float(total.detach()); return total,out
