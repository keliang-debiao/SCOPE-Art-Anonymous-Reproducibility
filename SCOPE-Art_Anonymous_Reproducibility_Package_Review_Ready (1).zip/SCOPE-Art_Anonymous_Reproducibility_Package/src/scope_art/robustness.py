from PIL import Image, ImageFilter, ImageEnhance

def jpeg_roundtrip(im,quality=50):
    import io
    buf=io.BytesIO(); im.save(buf,format='JPEG',quality=quality); buf.seek(0); return Image.open(buf).convert('RGB')
def blur(im,radius=1.5): return im.filter(ImageFilter.GaussianBlur(radius))
def desaturate(im,factor=0.5): return ImageEnhance.Color(im).enhance(1-factor)
