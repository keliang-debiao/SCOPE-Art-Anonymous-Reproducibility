import sys, yaml, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))

import argparse, pandas as pd
from scope_art.data import make_group_folds
p=argparse.ArgumentParser(); p.add_argument('--config',required=True); a=p.parse_args(); cfg=yaml.safe_load(open(a.config))
df=pd.read_csv('manifests/met_final.csv'); out=make_group_folds(df,cfg['splitting']['n_splits']); out.to_csv('manifests/met_folds.csv',index=False); print(out.fold.value_counts().sort_index())
