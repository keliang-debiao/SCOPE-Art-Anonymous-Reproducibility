import sys, yaml, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
print('Run JPEG, blur, desaturation, context-lens masking, and reduced-training-data conditions from frozen evaluation checkpoints.')
