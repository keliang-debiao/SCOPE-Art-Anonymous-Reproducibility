import sys, yaml, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
print('Generate manuscript tables/figures only from machine-readable result files; do not type results manually.')
