import sys, yaml, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))

import argparse, pandas as pd
from scope_art.data import add_hashes,cross_collection_audit
p=argparse.ArgumentParser(); p.add_argument('--config',required=True); a=p.parse_args(); cfg=yaml.safe_load(open(a.config))
met=add_hashes(pd.read_csv('manifests/met_raw.csv')); pr=add_hashes(pd.read_csv('manifests/prado_raw.csv'))
met.to_csv('manifests/met_hashed.csv',index=False); pr.to_csv('manifests/prado_hashed.csv',index=False)
exact,near=cross_collection_audit(met,pr,cfg['hashing']['hamming_threshold'])
Path('results').mkdir(exist_ok=True); json.dump({'cross_sha256_exact':len(exact),'cross_phash_near':len(near),'threshold':cfg['hashing']['hamming_threshold']},open('results/cross_collection_audit.json','w'),indent=2)
print(json.dumps({'exact':len(exact),'near':len(near)},indent=2))
