import sys, yaml, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))

print('External validation contract: load only frozen fold/final checkpoints; do not fit, early-stop, recalibrate, or tune on Prado.')
