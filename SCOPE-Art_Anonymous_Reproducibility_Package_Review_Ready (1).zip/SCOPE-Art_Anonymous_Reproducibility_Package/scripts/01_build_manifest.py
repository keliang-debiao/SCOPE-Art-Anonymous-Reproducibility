import sys, yaml, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))

import argparse, pandas as pd
p=argparse.ArgumentParser(); p.add_argument('--config',required=True); a=p.parse_args(); cfg=yaml.safe_load(open(a.config))
for name in ['met','prado']:
    c=cfg[name]; df=pd.read_csv(c['metadata_csv'])
    out=pd.DataFrame({'sample_id':df[c['id_col']].astype(str),'image_path':df[c['image_col']].astype(str),'title':df[c['title_col']].fillna(''),'creator':df[c['creator_col']].fillna(''),'date':df[c['date_col']].fillna(''),'material':df[c['material_col']].fillna('')})
    Path('manifests').mkdir(exist_ok=True); out.to_csv(f'manifests/{name}_raw.csv',index=False); print(name,len(out))
