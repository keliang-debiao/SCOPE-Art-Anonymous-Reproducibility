import sys, yaml, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
print('Use paired query-level bootstrap, Holm correction, and Cliff's delta. Fold-level t-CI is reserved for the five outer-fold means.')
