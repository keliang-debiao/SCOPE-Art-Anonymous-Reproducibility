import sys, yaml, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))

import numpy as np
from scope_art.metrics import retrieval_metrics
from scope_art.calibration import top1_conf_correct

def matched_gallery(sim, T, gallery_size=8040, repeats=100, seed0=1000):
    n=sim.shape[0]
    if gallery_size>n: raise ValueError('gallery_size exceeds this outer validation fold; use fold-valid setting or dataset-specific protocol')
    out=[]
    for s in range(seed0,seed0+repeats):
        rng=np.random.default_rng(s); idx=np.sort(rng.choice(n,gallery_size,replace=False)); sub=sim[np.ix_(idx,idx)]
        m=retrieval_metrics(sub); conf,corr=top1_conf_correct(sub,T); m['ece15']=__import__('scope_art.metrics',fromlist=['ece']).ece(conf,corr,15); m['brier']=__import__('scope_art.metrics',fromlist=['brier']).brier(conf,corr); out.append(m)
    return out
print('Use within each outer validation fold only; never mix fold-specific embedding spaces.')
