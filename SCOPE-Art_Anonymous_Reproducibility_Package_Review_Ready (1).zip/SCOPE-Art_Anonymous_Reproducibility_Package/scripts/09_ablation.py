import sys, yaml, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
print('Ablations: w/o SRTM, w/o CLF, w/o SCBE, w/o L_str, w/o L_lens, single concatenated context, dense FFN.')
