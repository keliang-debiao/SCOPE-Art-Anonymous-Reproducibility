import sys, yaml, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))

import argparse, pandas as pd, numpy as np
p=argparse.ArgumentParser(); p.add_argument('--run-dir',required=True); a=p.parse_args()
files=list(Path(a.run_dir).glob('fold*_metrics.json'))
if not files: raise SystemExit('No fold metric files found')
rows=[json.load(open(f)) for f in files]; df=pd.DataFrame(rows); print(df.describe())
