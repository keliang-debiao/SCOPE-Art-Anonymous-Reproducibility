import sys, yaml, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))

"""Full training entry point.
Connect dataset-specific image/text encoding to the SCOPE-Art core. The script intentionally does not fabricate missing data or checkpoints.
"""
import argparse
p=argparse.ArgumentParser(); p.add_argument('--config',required=True); a=p.parse_args(); cfg=yaml.safe_load(open(a.config))
print('Validated config:', cfg['experiment_name'])
print('Implement/run full SigLIP2 training after public datasets are installed. See docs/PROTOCOL.md.')
